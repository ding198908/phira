
retry = RETRY
proceed = PROCEED
detail = DETAILS

new-best = NEW BEST
max-combo = MAX COMBO
rks-delta = RKS CHANGE
accuracy = Accuracy
error = Error

uploading = Uploading record…
uploaded = Score uploaded.
upload-failed = Failed to upload.
upload-cancel = Cancel Upload
upload-retry = Retry Upload

still-uploading = Uploading record to leaderboard…

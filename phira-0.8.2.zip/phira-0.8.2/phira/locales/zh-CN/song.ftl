
load-preview-failed = 加载歌曲预览失败
load-charts-failed = 加载难度失败

load-chart-failed = 加载谱面失败

dl-cancel = 取消
dl-status-fetch = 加载信息
dl-status-song = 下载歌曲
dl-status-chart = 下载谱面
dl-status-extract = 解压中
dl-status-illustration = 下载插图
dl-status-assets = 下载资源
dl-status-saving = 保存中
dl-failed = 下载失败
dl-success = 下载完成

guest = 游客

warn-unrated = 本次游玩不计成绩
failed-to-play = 启动在线模式失败
play-cancel = 取消
play-switch-to-offline = 切换到离线模式
switched-to-offline = 已切换到离线模式

delete = 删除
rate = 评分
exercise = 练习
offset = 调整延迟
unlock = 播放解锁动画

edit-cancel = 取消
edit-save = 保存
edit-saving = 保存中
edit-load-file-failed = 加载外部文件失败
edit-save-failed = 保存失败
edit-saved = 保存成功
edit-preview-invalid = 预览时间超出范围
edit-tags = 编辑标签
edit-downloaded = 你不能编辑下载的谱面
edit-overwrite = 覆盖
edit-overwrite-confirm = 你确定要使用外部的谱面覆盖当前的谱面吗？（只有在点击“更新”后才会同步到在线平台）
edit-overwrite-success = 已覆盖
edit-overwrite-failed = 覆盖失败

edit-upload = 上传
edit-update = 更新

warn = 警告
cancel-not-saved = 你还没有保存信息，确定要退出吗？
upload-not-saved = 你还没有保存谱面，确定要继续上传吗？
upload-login-first = 请先登录
upload-builtin = 不能上传内置谱面
upload-rules = 上传须知
upload-rules-content =
  在上传前，你需要确认：
  1. ！谱面必须为本人创作，合作需具有所有创作者的上传许可，否则可能面临永久禁止上传的惩罚
  2. 建议使用辨识度高的头像和 ID；如果你在 Phira 使用的头像 ID 与自制谱视频发布平台（具体而言，BiliBili）有较大出入，需要额外标注。同时请注明方便使用的语言（若非汉语）
  3. 谱面内容（包括音乐、插图、文字等）须符合中华人民共和国其他法律法规，不得违法或包含不良信息
  4. 上传者上传即同意谱面可用于 Phira 的公开宣传，其他方式利用仍需谱师许可
  5. 本须知最终解释权归 TeamFlos 所有
uploading = 上传中…
upload-chart-failed = 上传谱面失败
upload-success = 上传成功，请等待审核！
upload-failed = 上传失败
upload-confirm-clear-ldb = 由于当前谱面文件和远端谱面文件不同，上传谱面后将清空该谱面的排行榜，确定要继续吗？

ldb = 排行榜
ldb-load-failed = 加载排行榜失败
ldb-no-rank = 无
ldb-score = 分数
ldb-std = 无瑕度

info-name = 名字
info-composer = 曲师
info-charter = 谱师
info-difficulty = 难度
info-desc = 简介
info-collaborators = 协作者
info-rating = 评分
info-type = 种类
info-tags = 标签

collab-autocomplete-title = 协作者补全
collab-autocomplete-content = 检测到缺少用户 ID 的协作者：{ $mentions }，是否自动补全？
collab-autocomplete-failed = 无法解析 "@{ $name }"：用户不存在或有多个匹配。
collab-autocomplete-done = 协作者已补全

reviewed = 已审核
unreviewed = 未审核

review-approve = 通过
review-approve-confirm = 确定通过该谱面吗？该操作无法撤销。
review-deny = 拒绝
review-del = 删除在线
review-approved = 已通过
review-passed = 已通过，谱面已过审
review-denied = 已拒绝
review-deleted = 已删除
review-action-failed = 执行审核操作失败
review-doing = 执行操作中
review-not-loaded = 信息尚未加载完成，请稍等
review-edit-tags = 编辑标签
review-edit-tags-failed = 编辑标签失败
review-edit-tags-done = 标签已更新

mods = Mods
mods-autoplay = 自动游玩
mods-autoplay-sub = 启用后将无法上传成绩
mods-flip-x = X 轴反转
mods-flip-x-sub = 在 X 轴上反转谱面
mods-fade-in = 上隐
mods-fade-in-sub = 音符在靠近判定线时会显现
mods-fade-out = 下隐
mods-fade-out-sub = 音符在靠近判定线时会隐藏
mods-nightcore = 夜店
mods-nightcore-sub = 以高倍速游玩谱面
mods-rainbow = 彩虹
mods-rainbow-sub = 遇上彩虹，吃定彩虹
mods-instant-death-ap = 突然死亡（AP）
mods-instant-death-ap-sub = 非完美判定立即失败
mods-instant-death-fc = 突然死亡（FC）
mods-instant-death-fc-sub = 连击中断立即失败
mods-no-shader = 无着色器
mods-no-shader-sub = 禁用着色器特效。*启用此 Mod 后无法上传成绩*

rate-failed = 评分失败
rate-done = 评分成功

need-update = 谱面更新
need-update-info-only-content = 谱面信息已更新，需要现在同步这些信息吗？
need-update-content = 谱面已更新，若本地不更新您将无法上传成绩。需要现在更新吗？

request-failed = 请求失败

stabilize = 申请 stable
stabilize-warn = 普通用户每 3 天可以申请一次 stable 谱面。至少拥有一张 stable 谱面的用户每 1 天可以申请一次。
stabilize-requested = 申请 stable 成功
stabilize-failed = 申请 stable 失败
stabilize-approve = 通过 special
stabilize-approve-ranked = 通过 stable
stabilize-approve-confirm = 确定通过该谱面的评议吗？该操作无法撤销。
stabilize-comment = Stable 留言
stabilize-commented = 留言成功
stabilize-deny = 拒绝 stable
stabilize-approved = 已通过
stabilize-approved-passed = 已通过，谱面已 stable
stabilize-denied = 已拒绝
stabilize-denied-passed = 已拒绝，谱面已打回

fav-added = 已收藏（长按以选择其他收藏夹）

still-loading = 仍在加载中…

export = 导出
exporting = 导出中…

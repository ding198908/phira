login = Войти
login-sub = Войдите для онлайн-доступа Phira (чарты, события, мультиплеер т.д.).
back-login = Назад
register = Регистрация
email = Почта
username = Никнейм
password = Пароль
name-length-req = Длина никнейма не может быть меньше { $min }-x или больше { $max } символов.
name-has-illegal-char = В никнейме есть неподходящие символы.
pwd-length-req = Длина пароля не может быть меньше { $min } или больше { $max } символов.
illegal-email = Неправильно введëн адрес почты.
action-success =
    { $action ->
        [login] Вход успешен
        [register] Регистрация успешна
       *[other] _
    }
action-failed =
    { $action ->
        [login] Ошибка при входе
        [register] Ошибка при регистрации
       *[other] _
    }
email-sent = На вашу почту пришло верификационное письмо. Подтвердите свою почту, после чего войдите в аккаунт.
forget-password = Забыли пароль?

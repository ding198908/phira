label = СКИНЫ
default = По умолчанию
load-failed = Ошибка загрузки ресурспака
info = Информация о ресурспаке
info-content =
    Имя: { $name }
    Автор: { $author }
    Описание: { $desc }
cant-delete-builtin = Невозможно удалить встроенный ресурспак
deleted = Удалено

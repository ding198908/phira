
label = KALİBRASYON

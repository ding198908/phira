time = Czas
name = Nazwa